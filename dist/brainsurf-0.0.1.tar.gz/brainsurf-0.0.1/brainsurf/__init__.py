# Define constants and configuration settings
VERSION = '0.0.1'


