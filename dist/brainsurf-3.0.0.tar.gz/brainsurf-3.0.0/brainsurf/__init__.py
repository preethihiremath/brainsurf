# Define constants and configuration settings
VERSION = '3.0.0'


