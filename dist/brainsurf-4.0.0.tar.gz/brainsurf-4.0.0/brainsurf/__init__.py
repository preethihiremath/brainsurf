# Define constants and configuration settings
VERSION = '4.0.0'


