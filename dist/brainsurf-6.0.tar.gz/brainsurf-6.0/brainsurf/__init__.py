# Define constants and configuration settings
VERSION = '6.0'


