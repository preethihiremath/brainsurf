#Import sub-modules and packages
#contain code that needs to be executed once when the package is imported

# Define constants and configuration settings
VERSION = '1.0'

